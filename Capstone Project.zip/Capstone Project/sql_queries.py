import configparser


# CONFIG
config = configparser.ConfigParser()
config.read('dwh.cfg')

ECOMMERCE_DATA = config.get('S3', 'ECOMMERCE_DATA')
MARKETING_FUNNEL_DATA = config.get('S3', 'MARKETING_FUNNEL_DATA')
DWH_IAM_ROLE_ARN = config.get("IAM_ROLE", "ARN")

# DROP TABLES

staging_customers_table_drop       = "DROP TABLE IF EXISTS staging_customers"
staging_geolocation_table_drop     = "DROP TABLE IF EXISTS staging_geolocation"
staging_items_table_drop           = "DROP TABLE IF EXISTS staging_items" 
staging_payments_table_drop        = "DROP TABLE IF EXISTS staging_payments"
staging_reviews_table_drop         = "DROP TABLE IF EXISTS staging_reviews"
staging_orders_table_drop          = "DROP TABLE IF EXISTS staging_orders"
staging_products_table_drop        = "DROP TABLE IF EXISTS staging_products"
staging_sellers_table_drop         = "DROP TABLE IF EXISTS staging_sellers"
staging_closed_deals_table_drop    = "DROP TABLE IF EXISTS staging_closed_deals"
staging_qualified_leads_table_drop = "DROP TABLE IF EXISTS staging_qualified_leads"


# CREATE TABLES

staging_customers_table_create= (
        """
        CREATE TABLE staging_customers 
        (
            customer_id                 VARCHAR    NOT NULL,
            customer_unique_id          VARCHAR    NOT NULL,
            customer_zip_code_prefix    INT        NOT NULL,
            customer_city               VARCHAR    NOT NULL,
            customer_state              VARCHAR    NOT NULL
        );
        """
)

staging_geolocation_table_create= (
        """
        CREATE TABLE staging_geolocation 
        (
            geolocation_zip_code_prefix    INT        NOT NULL,
            geolocation_lat                FLOAT      NOT NULL, 
            geolocation_lng                FLOAT      NOT NULL,
            geolocation_city               VARCHAR    NOT NULL,
            geolocation_state              VARCHAR    NOT NULL
        );
        """
)

staging_items_table_create= (
        """
        CREATE TABLE staging_items 
        (
            order_id               VARCHAR      NOT NULL,
            order_item_id          INT          NOT NULL,
            product_id             VARCHAR      NOT NULL,
            seller_id              VARCHAR      NOT NULL,
            shipping_limit_date    TIMESTAMP    NOT NULL,
            price                  FLOAT        NOT NULL,
            freight_value          FLOAT        NOT NULL
        );
        """
)

staging_payments_table_create= (
        """
        CREATE TABLE staging_payments 
        (
            order_id                VARCHAR    NOT NULL,
            payment_sequential      INT        NOT NULL,
            payment_type            VARCHAR    NOT NULL,
            payment_installments    INT        NOT NULL,
            payment_value           FLOAT      NOT NULL
        );
        """
)

staging_reviews_table_create= (
        """
        CREATE TABLE staging_reviews 
        (
            review_id                  VARCHAR      NOT NULL,
            order_id                   VARCHAR      NOT NULL,
            review_score               INT          NOT NULL,
            review_comment_title       VARCHAR,
            review_comment_message     VARCHAR(999),
            review_creation_date       TIMESTAMP    NOT NULL,
            review_answer_timestamp    TIMESTAMP    NOT NULL
        );
        """
)

staging_orders_table_create= (
        """
        CREATE TABLE staging_orders 
        (
            order_id                         VARCHAR      NOT NULL,
            customer_id                      VARCHAR      NOT NULL,
            order_status                     VARCHAR      NOT NULL,
            order_purchase_timestamp         TIMESTAMP    NOT NULL,
            order_approved_at                TIMESTAMP,
            order_delivered_carrier_date     TIMESTAMP,
            order_delivered_customer_date    TIMESTAMP,
            order_estimated_delivery_date    TIMESTAMP    NOT NULL
        );
        """
)

staging_products_table_create= (
        """
        CREATE TABLE staging_products 
        (
            product_id                    VARCHAR    NOT NULL,
            product_category_name         VARCHAR,
            product_name_lenght           FLOAT,
            product_description_lenght    FLOAT,
            product_photos_qty            FLOAT,
            product_weight_g              FLOAT,
            product_length_cm             FLOAT,
            product_height_cm             FLOAT,
            product_width_cm              FLOAT  
        );
        """
)

staging_sellers_table_create= (
        """
        CREATE TABLE staging_sellers 
        (
            seller_id                 VARCHAR    NOT NULL,
            seller_zip_code_prefix    INT        NOT NULL,
            seller_city               VARCHAR    NOT NULL,
            seller_state              VARCHAR    NOT NULL
        );
        """
)

staging_closed_deals_table_create= (
        """
        CREATE TABLE staging_closed_deals 
        (
            mql_id                           VARCHAR      NOT NULL,
            seller_id                        VARCHAR      NOT NULL,
            sdr_id                           VARCHAR      NOT NULL,
            sr_id                            VARCHAR      NOT NULL,
            won_date                         TIMESTAMP    NOT NULL,
            business_segment                 VARCHAR,
            lead_type                        VARCHAR,
            lead_behaviour_profile           VARCHAR,
            has_company                      VARCHAR,
            has_gtin                         VARCHAR,
            average_stock                    VARCHAR,
            business_type                    VARCHAR,
            declared_product_catalog_size    FLOAT,
            declared_monthly_revenue         FLOAT        NOT NULL
        );
        """
)

staging_qualified_leads_table_create= (
        """
        CREATE TABLE staging_qualified_leads 
        (
            mql_id                VARCHAR      NOT NULL,
            first_contact_date    TIMESTAMP    NOT NULL,
            landing_page_id       VARCHAR      NOT NULL,
            origin                VARCHAR
        );
        """
)


# STAGING TABLES

staging_customers_copy = (
    """
    COPY staging_customers 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_customers_dataset.csv', DWH_IAM_ROLE_ARN)

staging_geolocation_copy = (
    """
    COPY staging_geolocation
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_geolocation_dataset.csv', DWH_IAM_ROLE_ARN)

staging_items_copy = (
    """
    COPY staging_items 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_order_items_dataset.csv', DWH_IAM_ROLE_ARN)

staging_payments_copy = (
    """
    COPY staging_payments 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_order_payments_dataset.csv', DWH_IAM_ROLE_ARN)

staging_reviews_copy = (
    """
    COPY staging_reviews 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_order_reviews_dataset.csv', DWH_IAM_ROLE_ARN)

staging_orders_copy = (
    """
    COPY staging_orders 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_orders_dataset.csv', DWH_IAM_ROLE_ARN)

staging_products_copy = (
    """
    COPY staging_products 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_products_dataset.csv', DWH_IAM_ROLE_ARN)

staging_sellers_copy = (
    """
    COPY staging_sellers 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(ECOMMERCE_DATA + 'olist_sellers_dataset.csv', DWH_IAM_ROLE_ARN)

staging_closed_deals_copy = (
    """
    COPY staging_closed_deals 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(MARKETING_FUNNEL_DATA + 'olist_closed_deals_dataset.csv', DWH_IAM_ROLE_ARN)

staging_qualified_leads_copy = (
    """
    COPY staging_qualified_leads 
    FROM '{}'
    iam_role '{}'
    IGNOREHEADER 1
    CSV
    """
).format(MARKETING_FUNNEL_DATA + 'olist_marketing_qualified_leads_dataset.csv', DWH_IAM_ROLE_ARN)


# QUERY LISTS

create_table_queries = [staging_customers_table_create, staging_geolocation_table_create, staging_items_table_create, staging_payments_table_create, staging_reviews_table_create, staging_orders_table_create, staging_products_table_create, staging_sellers_table_create, staging_closed_deals_table_create, staging_qualified_leads_table_create]

drop_table_queries = [staging_customers_table_drop, staging_geolocation_table_drop, staging_items_table_drop, staging_payments_table_drop, staging_reviews_table_drop, staging_orders_table_drop, staging_products_table_drop, staging_sellers_table_drop, staging_closed_deals_table_drop, staging_qualified_leads_table_drop]

copy_table_queries = [staging_customers_copy, staging_geolocation_copy, staging_items_copy, staging_payments_copy, staging_reviews_copy, staging_orders_copy, staging_products_copy, staging_sellers_copy, staging_closed_deals_table_drop, staging_qualified_leads_copy]

